package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<State> states = new ArrayList<State>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // начальная инициализация списка
        setInitialData();
        RecyclerView recyclerView = findViewById(R.id.list);
        // создаем адаптер
        StateAdapter adapter = new StateAdapter(this, states);
        // устанавливаем для списка адаптер
        recyclerView.setAdapter(adapter);
    }
    private void setInitialData(){

        states.add(new State ("Нигер", "Ниамей", R.drawable.anim1));
        states.add(new State ("Чад", "Нджамена", R.drawable.anim2));
        states.add(new State ("Мали", "Бамако", R.drawable.anim4));
        states.add(new State ("Баркино-Фасо", "Уагадугу", R.drawable.anim5));
        states.add(new State ("Бенин", "Порто-Ново", R.drawable.anim6));
        states.add(new State ("Гвинея", "Конакри", R.drawable.anim7));
        states.add(new State ("Сенегал", "Дакар", R.drawable.anim8));
        states.add(new State ("Нигерия", "Абуджа", R.drawable.anim9));
        states.add(new State ("Габон", "Либревиль", R.drawable.anim10));
        states.add(new State ("Камерун", "Яунде", R.drawable.anim11));
        states.add(new State ("Танзания", "Додома", R.drawable.anim12));
        states.add(new State ("Гамбия", "Банжул", R.drawable.anim13));
        states.add(new State ("Гана", "Аккра", R.drawable.anim14));

    }
}